/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd.server;

/**
 *
 * @author António Gonçalves e Afonso Costa
 */
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.*;
import shared.AuthenticationService;
import shared.User;

public class AuthenticationServiceImpl extends UnicastRemoteObject implements AuthenticationService {

    private final ExecutorService executorService;
    private final LinkedBlockingQueue<Runnable> taskQueue;

    public AuthenticationServiceImpl() throws RemoteException {
        super();
        // Fila para armazenar as requisições
        this.taskQueue = new LinkedBlockingQueue<>(100);  // Limite de 100 tarefas
        // ExecutorService para consumir as tarefas da fila
        this.executorService = Executors.newFixedThreadPool(10);  // 10 threads para processar as tarefas
        startProcessingQueue();  // Inicia o processamento das tarefas
    }

    // Método para processar as tarefas da fila
    private void startProcessingQueue() {
        Runnable taskProcessor = () -> {
            try {
                while (true) {
                    Runnable task = taskQueue.take();  // Espera por uma tarefa
                    task.run();  // Executa a tarefa
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        };

        // Inicia uma thread para processar a fila
        new Thread(taskProcessor).start();
    }

    @Override
    public boolean login(String username, String password) throws RemoteException {
        // Envia a tarefa para a fila de requisições
        taskQueue.offer(() -> {
            try {
                User user = new User(username);
                // Tentamos carregar as chaves do usuário a partir do arquivo
                try {
                    user.load(password);
                    System.out.println("Login bem-sucedido para " + username);
                } catch (Exception e) {
                    System.out.println("Falha no login para " + username);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Para o cliente, sempre retorna true ou false (não espera o resultado diretamente)
        return true;  // Assumimos que o login foi enviado para a fila
    }

    
    /***
     * 
     * @param username
     * @param password
     * @return
     * @throws RemoteException 
     * 
     * 1ºpasso: cria o utilizador com o username correspondente.
     * 2ºpasso: gera as chaves publica, privada e simetrica.
     * 3ºpasso: salva as chaves em ficheiros.
     * 
     */
    @Override
    public boolean register(String username, String password) throws RemoteException {
        // Envia a tarefa de registro para a fila de requisições
        taskQueue.offer(() -> {
            try {
                User user = new User(username);
                user.generateKeys();
                user.save(password); 
                System.out.println("Registro bem-sucedido para " + username);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        return true;  // Assumimos que o registro foi enviado para a fila
    }

    public void shutdown() {
        executorService.shutdown();  // Encerra o ExecutorService
    }
}

