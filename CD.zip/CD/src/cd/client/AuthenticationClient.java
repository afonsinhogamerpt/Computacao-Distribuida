/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cd.client;

import java.util.Scanner;
import java.rmi.Naming;
import shared.AuthenticationService;

/**
 *
 * @author António Gonçalves e Afonso Costa
 */
public class AuthenticationClient {
    
     public static void main(String[] args) {
        try {
            // Fazendo lookup no RMI Registry para o serviço de autenticação
            AuthenticationService authService = (AuthenticationService) Naming.lookup("//localhost:1099/AuthenticationService");

            Scanner scanner = new Scanner(System.in);
            System.out.println("Digite 1 para Login ou 2 para Registro:");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Limpa o buffer

            System.out.println("Digite o nome de usuário:");
            String username = scanner.nextLine();
            System.out.println("Digite a senha:");
            String password = scanner.nextLine();

            boolean result;
            if (choice == 1) {
                result = authService.login(username, password);  // Chama o método de login no servidor
            } else if (choice == 2) {
                result = authService.register(username, password);  // Chama o método de registro no servidor
            } else {
                System.out.println("Opção inválida.");
                return;
            }

            if (result) {
                System.out.println("Operação bem-sucedida!");
            } else {
                System.out.println("Falha na operação.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
